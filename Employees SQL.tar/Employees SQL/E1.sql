WITH RECURSIVE employees AS (
    SELECT
        id,
        name,
        department,
        manager_id,
        0 AS level
    FROM employees
    WHERE manager_id IS NULL

    UNION ALL

    SELECT
        e.id,
        e.name,
        e.department,
        e.manager_id,
        eh.level + 1 AS level
    FROM employees e
    JOIN employees e
        ON e.manager_id = e.id
)
SELECT *
FROM employees
ORDER BY level, id;
