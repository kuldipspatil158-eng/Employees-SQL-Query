# How do you use a CTE to get the top 3 highest-paid employees in each department?

WITH TopSalaries AS (
SELECT name, department, salary,
DENSE_RANK() OVER (PARTITION BY department ORDER BY salary DESC) AS rnk
FROM employees
)
SELECT * FROM TopSalaries WHERE rnk <= 3;

