# How do you identify departments where salaries are increasing over time?

WITH dept_salary AS (
    SELECT
        department,
        DATE_FORMAT(hire_date, '%Y-%m-01') AS month,
        AVG(salary) AS avg_salary
    FROM employees
    GROUP BY department, DATE_FORMAT(hire_date, '%Y-%m-01')
),
salary_trend AS (
    SELECT
        department,
        month,
        avg_salary,
        LAG(avg_salary) OVER (
            PARTITION BY department
            ORDER BY month
        ) AS prev_avg_salary
    FROM dept_salary
)
SELECT DISTINCT department
FROM salary_trend
WHERE avg_salary > prev_avg_salary;




WITH SalaryTrend AS (
 SELECT department, name, salary, hire_date,
 LAG(salary) OVER (PARTITION BY department ORDER BY hire_date) AS prev_salary
 FROM employees
)
SELECT * FROM SalaryTrend WHERE salary > prev_salary;
