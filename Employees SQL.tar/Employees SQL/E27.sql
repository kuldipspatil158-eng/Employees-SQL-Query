#  How do you identify departments where salary expenses exceed a given threshold?

WITH DeptSalaries AS (
SELECT department, SUM(salary) AS total_salary FROM employees GROUP BY department
)
SELECT * FROM DeptSalaries WHERE total_salary > 150000;