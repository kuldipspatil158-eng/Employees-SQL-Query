# How can you identify employees without direct reports?


SELECT e.id, e.name, e.department AS Report_count
FROM employees e
LEFT JOIN employees m
    ON e.id = m.manager_id
WHERE m.manager_id IS NULL;




SELECT e.id, e.name, e.department
FROM employees e
WHERE NOT EXISTS (
    SELECT 1
    FROM employees m
    WHERE m.manager_id = e.id);




SELECT department, COUNT(*) AS individual_contributors
FROM employees e
WHERE NOT EXISTS (
    SELECT 1
    FROM employees m
    WHERE m.manager_id = e.id
)
GROUP BY department;



WITH EmployeeReport AS (
 SELECT e1.id, e1.name, e1.department, COUNT(e2.id) AS report_count
 FROM employees e1 LEFT JOIN employees e2 ON e1.id = e2.manager_id
 GROUP BY e1.id, e1.name
)
SELECT * FROM EmployeeReport WHERE report_count = 0;
