#  How do you calculate the percentage of total salary each employee contributes within a department?

WITH SalaryShare AS (
SELECT department, name, salary,
salary * 100.0 / SUM(salary) OVER (PARTITION BY department) AS percentage
FROM employees
)
SELECT * FROM SalaryShare;