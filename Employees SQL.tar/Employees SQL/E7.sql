# How do you find employees who are earning below the department’s average salary?


SELECT
    e.id,
    e.name,
    e.department,
    e.salary
FROM employees e
JOIN (
    SELECT department, AVG(salary) AS avg_salary
    FROM employees
    GROUP BY department
) d
ON e.department = d.department
WHERE e.salary < d.avg_salary;
