#  How do you use a CTE to remove duplicate salaries while keeping the latest employee?

WITH RankedEmployees AS (
SELECT *, ROW_NUMBER() OVER (PARTITION BY salary ORDER BY hire_date DESC) AS rn
FROM employees
)
SELECT * FROM RankedEmployees WHERE rn = 1;