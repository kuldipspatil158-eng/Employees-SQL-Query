#  How do you identify employees earning within a certain percentile using a CTE?

WITH SalaryPercentile AS (
SELECT name, salary,
NTILE(4) OVER (ORDER BY salary DESC) AS salary_quartile
FROM employees
)
SELECT * FROM SalaryPercentile WHERE salary_quartile = 1;