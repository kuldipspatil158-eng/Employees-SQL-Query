# How do you identify employees hired in the same year as their manager?

SELECT
    e.id AS employee_id,
    e.name AS employee_name,
    m.name AS manager_name,
    e.hire_date AS employee_hire_date,
    m.hire_date AS manager_hire_date
FROM employees e
JOIN employees m
    ON e.manager_id = m.id
WHERE YEAR(e.hire_date) = YEAR(m.hire_date);




WITH HireYears AS (
 SELECT e1.name AS emp_name, e1.hire_date AS emp_hire, 
 e2.name AS mgr_name, e2.hire_date AS mgr_hire
 FROM employees e1 JOIN employees e2 ON e1.manager_id = e2.id)
 SELECT * FROM HireYears WHERE EXTRACT(YEAR FROM emp_hire) = EXTRACT(YEAR
FROM mgr_hire);