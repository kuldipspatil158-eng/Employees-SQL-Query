# How do you calculate rolling 3-month average salary per department?

WITH monthly_salary AS (
    SELECT
        department,
        DATE_FORMAT(hire_date, '%Y-%m-01') AS month,
        AVG(salary) AS avg_salary
    FROM employees
    GROUP BY department, DATE_FORMAT(hire_date, '%Y-%m-01')
)
SELECT
    department,
    month,
    avg_salary,
    AVG(avg_salary) OVER (
        PARTITION BY department
        ORDER BY month
    ) AS rolling_3_month_avg
FROM monthly_salary
ORDER BY department, month;
