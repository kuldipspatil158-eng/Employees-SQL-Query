#  How do you generate a sequence of numbers using a recursive CTE?

WITH RECURSIVE NumberSequence AS (
SELECT 1 AS num
UNION ALL
SELECT num + 1 FROM NumberSequence WHERE num < 10
)
SELECT * FROM NumberSequence;