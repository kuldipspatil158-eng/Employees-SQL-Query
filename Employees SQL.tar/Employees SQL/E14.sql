#  How can you use a CTE to generate Fibonacci numbers?

WITH RECURSIVE fibonacci_cte AS (
    
    SELECT 
        0 AS n,
        0 AS fib,
        1 AS next_fib

    UNION ALL

    SELECT
        n + 1,
        next_fib,
        fib + next_fib
    FROM fibonacci_cte
    WHERE n < 9
)
SELECT n, fib
FROM fibonacci_cte;
