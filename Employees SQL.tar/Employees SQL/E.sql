create database Employees;
Use  Employees;

create table employees(
id INT primary key,
name VARCHAR (100),
department VARCHAR (100),
manager_id INT,
salary DECIMAL(10,2),
hire_date DATE);

INSERT INTO employees(id,Name, Department, Manager_id, Salary, Hire_date)value
(1, 'Alice', 'HR', NULL, 70000, '2015-06-23'),
(2, 'Bob', 'IT', 1, 90000, '2016-09-17'),
(3, 'Charlie', 'Finance', 1, 80000, '2017-02-01'),
(4, 'David', 'IT', 2, 75000 , '2018-07-11'),
(5, 'Eve', 'Finance', 3, 72000, '2019-04-30');
