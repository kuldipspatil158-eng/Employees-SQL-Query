#  How do you determine which employees report directly or indirectly to a given manager?

WITH RECURSIVE EmployeeHierarchy AS (
SELECT id, name, manager_id FROM employees WHERE manager_id = 1
UNION ALL
SELECT e.id, e.name, e.manager_id FROM employees e JOIN EmployeeHierarchy eh ON e.manager_id = eh.id
)
SELECT * FROM EmployeeHierarchy;