#  How do you filter only employees who received a salary increase over time?

WITH SalaryChanges AS (
SELECT name, salary, hire_date,
LAG(salary) OVER (PARTITION BY name ORDER BY hire_date) AS prev_salary
FROM employees
)
SELECT * FROM SalaryChanges WHERE salary > prev_salary;