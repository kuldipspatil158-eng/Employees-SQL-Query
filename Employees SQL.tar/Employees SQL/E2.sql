# How do you calculate the number of levels in an organizational hierarchy?


WITH RECURSIVE emp_hierarchy AS (
   
    SELECT
        id,
        manager_id,
        1 AS level
    FROM employees
    WHERE manager_id IS NULL

    UNION ALL

 
    SELECT
        e.id,
        e.manager_id,
        eh.level + 1 AS level
    FROM employees e
    JOIN emp_hierarchy eh
        ON e.manager_id = eh.id
)
SELECT MAX(level) AS total_levels
FROM emp_hierarchy;
