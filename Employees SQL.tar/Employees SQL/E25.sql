#  How do you find the first and last employee hired in each department?

WITH HireOrder AS (
SELECT department, name, hire_date,
FIRST_VALUE(name) OVER (PARTITION BY department ORDER BY hire_date) AS first_hire,
LAST_VALUE(name) OVER (PARTITION BY department ORDER BY hire_date ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS last_hire
FROM employees
)
SELECT DISTINCT department, first_hire, last_hire FROM HireOrder;