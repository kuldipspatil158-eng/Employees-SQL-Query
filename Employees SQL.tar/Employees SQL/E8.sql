# How do you find the median salary per department using a CTE?

WITH salary_rank AS (
    SELECT
        department,
        salary,
        ROW_NUMBER() OVER (
            PARTITION BY department
            ORDER BY salary
        ) AS rn,
        COUNT(*) OVER (
            PARTITION BY department
        ) AS cnt
    FROM employees
)
SELECT
    department,
    AVG(salary) AS median_salary
FROM salary_rank
GROUP BY department;






SELECT department, AVG(salary) AS median_salary 
FROM employees
GROUP BY department;