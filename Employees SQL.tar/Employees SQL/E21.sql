#  How do you use a CTE to determine the cumulative headcount per year?


WITH YearlyHires AS (
SELECT EXTRACT(YEAR FROM hire_date) AS hire_year, COUNT(*) AS yearly_hires
FROM employees GROUP BY hire_year
)
SELECT hire_year, SUM(yearly_hires) OVER (ORDER BY hire_year) AS cumulative_hires FROM YearlyHires;