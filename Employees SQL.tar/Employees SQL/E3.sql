# How can you calculate cumulative salary within each department?

SELECT
    id,
    name,
    department,
    salary,
    SUM(salary) OVER (
        PARTITION BY department
        ORDER BY hire_date
    ) AS cumulative_salary
FROM employees
ORDER BY department, hire_date;
