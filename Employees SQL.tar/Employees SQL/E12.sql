# How do you find employees hired after their manager?

SELECT
    e.id AS employee_id,
    e.name AS employee_name,
    e.hire_date AS employee_hire_date,
    m.name AS manager_name,
    m.hire_date AS manager_hire_date
FROM employees e
JOIN employees m
    ON e.manager_id = m.id
WHERE e.hire_date > m.hire_date;
