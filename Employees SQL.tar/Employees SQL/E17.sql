# How can you find the longest-tenured employees using a CTE?

WITH Tenure AS (
SELECT name, hire_date,
RANK() OVER (ORDER BY hire_date ASC) AS tenure_rank
FROM employees
)
SELECT * FROM Tenure WHERE tenure_rank = 1;