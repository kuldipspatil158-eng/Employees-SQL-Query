#  How do you pivot department-wise employee counts using a CTE?

WITH dept_count AS (
    SELECT
        department,
        COUNT(*) AS emp_count
    FROM employees
    GROUP BY department
)
SELECT
    SUM(CASE WHEN department = 'HR' THEN emp_count ELSE 0 END) AS HR,
    SUM(CASE WHEN department = 'IT' THEN emp_count ELSE 0 END) AS IT,
    SUM(CASE WHEN department = 'Finance' THEN emp_count ELSE 0 END) AS Finance
FROM dept_count;

