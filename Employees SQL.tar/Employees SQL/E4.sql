# How do you find the most recent hire in each department?


SELECT id, name, department, hire_date
FROM (
    SELECT
        id,
        name,
        department,
        hire_date,
        ROW_NUMBER() OVER (
            PARTITION BY department
			ORDER BY hire_date DESC
        ) AS rn
    FROM employees
) t
WHERE rn = 1
ORDER BY hire_date DESC;




SELECT e.id, e.name, e.department, e.hire_date
FROM employees e

JOIN (
    SELECT department, MAX(hire_date) AS max_hire_date
    FROM employees
    GROUP BY department
) m
ON e.department = m.department
AND e.hire_date = m.max_hire_date
order by hire_date desc;