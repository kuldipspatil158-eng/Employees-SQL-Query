#  How do you rank employees within their department based on hire date using a CTE?

WITH HireRanking AS (
SELECT department, name, hire_date,
RANK() OVER (PARTITION BY department ORDER BY hire_date) AS hire_rank
FROM employees
)
SELECT * FROM HireRanking;