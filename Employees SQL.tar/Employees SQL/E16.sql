#  How do you calculate the difference in salary between an employee and their manager?


WITH SalaryComparison AS (
SELECT e1.name AS emp_name, e1.salary AS emp_salary, e2.name AS mgr_name, e2.salary AS mgr_salary,
(e1.salary - e2.salary) AS salary_diff
FROM employees e1 JOIN employees e2 ON e1.manager_id = e2.id
)
SELECT * FROM SalaryComparison;
