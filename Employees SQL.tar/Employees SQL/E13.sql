# How do you determine the highest and lowest-paid employees using a CTE?

WITH salary_cte AS (
    SELECT
        id,
        name,
        department,
        salary
    FROM employees
)
SELECT *
FROM salary_cte
WHERE salary = (SELECT MAX(salary) FROM salary_cte)
   OR salary = (SELECT MIN(salary) FROM salary_cte) ;



WITH salary_rank AS (
    SELECT
        id,
        name,
        department,
        salary,
        RANK() OVER (ORDER BY salary DESC) AS high_rank,
        RANK() OVER (ORDER BY salary ASC) AS low_rank
    FROM employees
)
SELECT id, name, department, salary
FROM salary_rank
WHERE high_rank = 1 OR low_rank = 1;



WITH salary_cte AS (
    SELECT
        id,
        name,
        department,
        salary,
        (SELECT MAX(salary) FROM employees) AS max_salary,
        (SELECT MIN(salary) FROM employees) AS min_salary
    FROM employees
)
SELECT
    id,
    name,
    department,
    salary,
    CASE
        WHEN salary = max_salary THEN 'Highest Paid'
        WHEN salary = min_salary THEN 'Lowest Paid'
    END AS type
FROM salary_cte
WHERE salary = max_salary
   OR salary = min_salary;
