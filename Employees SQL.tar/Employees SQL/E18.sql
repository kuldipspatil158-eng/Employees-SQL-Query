#  How can you create a CTE that identifies salary gaps between employees?

WITH SalaryGaps AS (
SELECT name, salary,
LAG(salary) OVER (ORDER BY salary) AS prev_salary,
salary - LAG(salary) OVER (ORDER BY salary) AS salary_gap
FROM employees
)
SELECT * FROM SalaryGaps;